self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dfe9dca88ebfde42b48f",
    "url": "/1.bundle.js"
  },
  {
    "revision": "dfe9dca88ebfde42b48f",
    "url": "/1.css"
  },
  {
    "revision": "96fafc37a4f7f8b5b883",
    "url": "/bundle.js"
  },
  {
    "revision": "13838608b96dccb41bb04799fafad3dc",
    "url": "/index.html"
  },
  {
    "revision": "96fafc37a4f7f8b5b883",
    "url": "/main.css"
  }
]);